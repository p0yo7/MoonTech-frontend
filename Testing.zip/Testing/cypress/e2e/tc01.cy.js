describe('Testing de Moontech', () => {
  beforeEach(() => {
    cy.visit('http://localhost:3000/login')
  })

  // TC-01
  it('should login successfully', () => {
    cy.get('input[name="username"]').type('poyo')
    cy.get('input[name="password"]').type('poyoyon!')
    cy.get('button[type="submit"]').click()

    // Verify loading state
    cy.get('button[type="submit"]').should('be.disabled')
    cy.get('button[type="submit"]').should('contain', 'Iniciando sesión...')

    // Verify redirect
    cy.url().should('include', '/dashboard')
  })

  // TC-02
  it('handles invalid credentials', () => {
    cy.get('input[name="username"]').type('wrong')
    cy.get('input[name="password"]').type('wrong')
    cy.get('button[type="submit"]').click()

    cy.intercept('POST', 'http://localhost:8080/login/native', {
      statusCode: 401,
      body: { message: 'Usuario o contraseña incorrectos' },
    }).as('loginRequest');
    
  })
  // TC-03
  it('handles incorrect password for a valid account', () => {
    cy.get('input[name="username"]').type('poyo') // Usuario existente
    cy.get('input[name="password"]').type('wrongpassword') // Contraseña incorrecta
    cy.get('button[type="submit"]').click()

    // Intercepta la solicitud al endpoint y simula respuesta de error
    cy.intercept('POST', 'http://localhost:8080/login/native', {
      statusCode: 401,
      body: { message: 'Usuario o contraseña incorrectos' },
    }).as('loginRequest')

  })
  // TC-04
  it('handles special characters in username or email', () => {
    // Usuario o correo con caracteres especiales
    const invalidUsername = 'user!@#';
    const password = 'poyoyon!';

    cy.get('input[name="username"]').type(invalidUsername)
    cy.get('input[name="password"]').type(password)
    cy.get('button[type="submit"]').click()

    // Intercepta la solicitud al endpoint y simula respuesta de error
    cy.intercept('POST', 'http://localhost:8080/login/native', {
      statusCode: 400,
      body: { message: 'El usuario o correo contiene caracteres no permitidos' },
    }).as('loginRequest')
  })
  // TC-05
  it('handles empty username and password fields', () => {
    // No se ingresan valores en los campos de usuario y contraseña
    cy.get('button[type="submit"]').click()

    // Intercepta la solicitud al endpoint y simula respuesta de error
    cy.intercept('POST', 'http://localhost:8080/login/native', {
      statusCode: 400,
      body: { message: 'Los campos usuario y contraseña no pueden estar vacíos' },
    }).as('loginRequest')

    // Espera a que la solicitud sea capturada
    // cy.wait('@loginRequest')

    // Verifica el mensaje de error en la interfaz
    // cy.get('.error-message').should('contain', 'Los campos usuario y contraseña no pueden estar vacíos')
  })
    // TC-06
    it('handles empty password field with valid email', () => {
      // Ingresar un correo válido pero dejar el campo de contraseña vacío
      cy.get('input[name="username"]').type('valid.email@empresa.com')
      cy.get('button[type="submit"]').click()
  
      // Intercepta la solicitud al endpoint y simula respuesta de error
      cy.intercept('POST', 'http://localhost:8080/login/native', {
        statusCode: 400,
        body: { message: 'El campo de contraseña no puede estar vacío' },
      }).as('loginRequest')
  
      // Espera a que la solicitud sea capturada
      // cy.wait('@loginRequest')
  
      // // Verifica el mensaje de error en la interfaz
      // cy.get('.error-message').should('contain', 'El campo de contraseña no puede estar vacío')
    })
  // TC-07
  it('handles empty username field with valid password', () => {
    // Ingresar una contraseña válida pero dejar el campo de usuario vacío
    cy.get('input[name="password"]').type('validpassword')
    cy.get('button[type="submit"]').click()

    // Intercepta la solicitud al endpoint y simula respuesta de error
    cy.intercept('POST', 'http://localhost:8080/login/native', {
      statusCode: 400,
      body: { message: 'El campo de usuario no puede estar vacío' },
    }).as('loginRequest')

    // Espera a que la solicitud sea capturada
    // cy.wait('@loginRequest')

    // // Verifica el mensaje de error en la interfaz
    // cy.get('.error-message').should('contain', 'El campo de usuario no puede estar vacío')
  })
    // TC-08
    it('handles login from multiple devices simultaneously', () => {
      // Simular el login en el primer dispositivo
      cy.visit('http://localhost:3000/login'); // Asegúrate de que la página de login se cargue correctamente
      cy.get('input[name="username"]').should('be.visible').type('poyo'); // Espera a que el campo de usuario sea visible
      cy.get('input[name="password"]').should('be.visible').type('poyoyon!');
      cy.get('button[type="submit"]').click();
      cy.url().should('include', '/dashboard'); // Verifica que redirige al menú principal
    
      // Simular el login en el segundo dispositivo
      cy.visit('http://localhost:3000/login'); // Visitar la página nuevamente para simular el segundo dispositivo
      cy.get('input[name="username"]').should('be.visible').type('poyo');
      cy.get('input[name="password"]').should('be.visible').type('poyoyon!');
      cy.get('button[type="submit"]').click();
      cy.url().should('include', '/dashboard'); // Verifica que redirige al menú principal
    });

    // TC-10
    it('handles login from multiple devices simultaneously', () => {
      // Simular el login en el primer dispositivo
      cy.visit('http://localhost:3000/login'); // Asegúrate de que la página de login se cargue correctamente
      cy.get('input[name="username"]').should('be.visible').type('poyo'); // Espera a que el campo de usuario sea visible
      cy.get('input[name="password"]').should('be.visible').type('poyoyon!');
      cy.get('button[type="submit"]').click();
      cy.url().should('include', '/dashboard'); // Verifica que redirige al menú principal
    
      // Simular el login en el segundo dispositivo
      cy.visit('http://localhost:3000/login'); // Visitar la página nuevamente para simular el segundo dispositivo
      cy.get('input[name="username"]').should('be.visible').type('poyo');
      cy.get('input[name="password"]').should('be.visible').type('poyoyon!');
      cy.get('button[type="submit"]').click();
      cy.url().should('include', '/dashboard'); // Verifica que redirige al menú principal
    });
    // TC-11
    it('handles the creation of a proyect using valid data', () => {
      // Ingresar al dashboard
      cy.visit('http://localhost:3000/login'); // Visitar la página nuevamente para simular el segundo dispositivo
      cy.get('input[name="username"]').should('be.visible').type('poyo');
      cy.get('input[name="password"]').should('be.visible').type('poyoyon!');
      cy.get('button[type="submit"]').click();
      cy.url().should('include', '/dashboard'); // Verifica que redirige al menú principal
    
      // Crear un nuevo proyecto
      cy.get('.rounded-lg').contains('Crear Nuevo Proyecto').click()
    
      // Ingresar datos válidos en el formulario
      cy.get('#projName').type('Nombre del Proyecto')
      cy.get('#owner').type('Nombre del Propietario')
      // Abrir el combobox
      cy.contains('Seleccionar empresa').click()
      // Seleccionar la primera opción (suponiendo que aparece en un listado)
      cy.get('[role="option"]').first().click()
      cy.contains('Seleccionar giro empresarial').click();
      cy.get('[role="option"]').first().click()
      cy.get('#budget').type(10000)
    
      // Enviar el formulario
      cy.contains('button', 'Crear Proyecto').click()
    
      // Verificar que el proyecto fue creado
      // cy.get('.project-card').should('have.length', 1)
      cy.url().should('include', '/requirements')
    });
    // TC-12
    it('handles the  creation of a proyect without projname', () => {
      // Ingresar al dashboard
      cy.visit('http://localhost:3000/login'); // Visitar la página nuevamente para simular el segundo dispositivo
      cy.get('input[name="username"]').should('be.visible').type('poyo');
      cy.get('input[name="password"]').should('be.visible').type('poyoyon!');
      cy.get('button[type="submit"]').click();
      cy.url().should('include', '/dashboard'); // Verifica que redirige al menú principal
    
      // Crear un nuevo proyecto
      cy.get('.rounded-lg').contains('Crear Nuevo Proyecto').click()
    
      // Ingresar datos válidos en el formulario
      // cy.get('#projName').type('Nombre del Proyecto')
      cy.get('#owner').type('Nombre del Propietario')
      // Abrir el combobox
      cy.contains('Seleccionar empresa').click()
      // Seleccionar la primera opción (suponiendo que aparece en un listado)
      cy.get('[role="option"]').first().click()
      cy.contains('Seleccionar giro empresarial').click();
      cy.get('[role="option"]').first().click()
      cy.get('#budget').type(10000)
    
      // Enviar el formulario
      cy.contains('button', 'Crear Proyecto').click()
    
      // Verificar que el proyecto fue creado
      // cy.get('.project-card').should('have.length', 1)
      cy.url().should('include', '/requirements')
    });
    // TC-12
    it('handles the  creation of a proyect without projname', () => {
      // Ingresar al dashboard
      cy.visit('http://localhost:3000/login'); // Visitar la página nuevamente para simular el segundo dispositivo
      cy.get('input[name="username"]').should('be.visible').type('poyo');
      cy.get('input[name="password"]').should('be.visible').type('poyoyon!');
      cy.get('button[type="submit"]').click();
      cy.url().should('include', '/dashboard'); // Verifica que redirige al menú principal
    
      // Crear un nuevo proyecto
      cy.get('.rounded-lg').contains('Crear Nuevo Proyecto').click()
    
      // Ingresar datos válidos en el formulario
      // cy.get('#projName').type('Nombre del Proyecto')
      // cy.get('#owner').type('Nombre del Propietario')
      // // Abrir el combobox
      // cy.contains('Seleccionar empresa').click()
      // // Seleccionar la primera opción (suponiendo que aparece en un listado)
      // cy.get('[role="option"]').first().click()
      // cy.contains('Seleccionar giro empresarial').click();
      // cy.get('[role="option"]').first().click()
      // cy.get('#budget').type(10000)
    
      // Enviar el formulario
      cy.contains('button', 'Crear Proyecto').click()
    
      // Verificar que el proyecto fue creado
      // cy.get('.project-card').should('have.length', 1)
      cy.url().should('include', '/dashboard')
    });
    // TC-14
    it('handles the creation of a proyect with offline servers', () => {
      // Ingresar al dashboard
      cy.visit('http://localhost:3000/login'); // Visitar la página nuevamente para simular el segundo dispositivo
      cy.get('input[name="username"]').should('be.visible').type('poyo');
      cy.get('input[name="password"]').should('be.visible').type('poyoyon!');
      cy.get('button[type="submit"]').click();
      cy.url().should('include', '/dashboard'); // Verifica que redirige al menú principal
    
      // Crear un nuevo proyecto
      cy.get('.rounded-lg').contains('Crear Nuevo Proyecto').click()
    
      // Ingresar datos válidos en el formulario
      cy.get('#projName').type('Nombre del Proyecto')
      cy.get('#owner').type('Nombre del Propietario')
      // Abrir el combobox
      cy.contains('Seleccionar empresa').click()
      // Seleccionar la primera opción (suponiendo que aparece en un listado)
      cy.get('[role="option"]').first().click()
      cy.contains('Seleccionar giro empresarial').click();
      cy.get('[role="option"]').first().click()
      cy.get('#budget').type(10000)
    
      // Enviar el formulario
      cy.contains('button', 'Crear Proyecto').click()
    
      // Verificar que el proyecto fue creado
      // cy.get('.project-card').should('have.length', 1)
      // cy.url().should('include', '/login')
    });
    // TC-15
    it('passes', () => {
      cy.visit('http://localhost:3000/login')
  
      // 1. Ingresar los datos correctos del usuario
      cy.get('input[name="username"]').type('poyo')
      cy.get('input[name="password"]').type('poyoyon!')
  
      // 2. Dar click en el botón de login
      cy.get('button[type="submit"]').click()
      cy.get('button svg.text-white').parent('button').click()
      cy.get('#companyName').type('Pollo Maton')
      cy.get('#companyDescription').type('Pollo Maton es una empresa que se dedica a la venta de pollo frito')
      cy.get('#companySize').select('Grande')
      cy.contains('Crear Empresa').click()
    })
    // TC-16
    it('passes', () => {
      cy.visit('http://localhost:3000/login')
  
      // 1. Ingresar los datos correctos del usuario
      cy.get('input[name="username"]').type('poyo')
      cy.get('input[name="password"]').type('poyoyon!')
  
      // 2. Dar click en el botón de login
      cy.get('button[type="submit"]').click()
      cy.get('button svg.text-white').parent('button').click()
      // cy.get('#companyName').type('Pollo Maton')
      // cy.get('#companyDescription').type('Pollo Maton es una empresa que se dedica a la venta de pollo frito')
      // cy.get('#companySize').select('Grande')
      cy.contains('Crear Empresa').click()
    });
    // TC-17
    it('handle company creation with offline servers', () => {
      cy.visit('http://localhost:3000/login')
  
      // 1. Ingresar los datos correctos del usuario
      cy.get('input[name="username"]').type('poyo')
      cy.get('input[name="password"]').type('poyoyon!')
  
      // 2. Dar click en el botón de login
      cy.get('button[type="submit"]').click()
      cy.get('button svg.text-white').parent('button').click()
      cy.get('#companyName').type('Pollo Maton')
      cy.get('#companyDescription').type('Pollo Maton es una empresa que se dedica a la venta de pollo frito')
      cy.get('#companySize').select('Grande')
      cy.contains('Crear Empresa').click()

    });
    // TC-18
    it('handle generate requirements', () => {
    cy.visit('http://localhost:3000/login'); // Visitar la página nuevamente para simular el segundo dispositivo
      cy.get('input[name="username"]').should('be.visible').type('poyo');
      cy.get('input[name="password"]').should('be.visible').type('poyoyon!');
      cy.get('button[type="submit"]').click();
      cy.url().should('include', '/dashboard'); // Verifica que redirige al menú principal
    
      // Crear un nuevo proyecto
      cy.get('.rounded-lg').contains('Crear Nuevo Proyecto').click()
    
      // Ingresar datos válidos en el formulario
      cy.get('#projName').type('Nombre del Proyecto')
      cy.get('#owner').type('Nombre del Propietario')
      // Abrir el combobox
      cy.contains('Seleccionar empresa').click()
      // Seleccionar la primera opción (suponiendo que aparece en un listado)
      cy.get('[role="option"]').first().click()
      cy.contains('Seleccionar giro empresarial').click();
      cy.get('[role="option"]').first().click()
      cy.get('#budget').type(10000)
    
      // Enviar el formulario
      cy.contains('button', 'Crear Proyecto').click()
    
      // Verificar que el proyecto fue creado
      // cy.get('.project-card').should('have.length', 1)
      cy.url().should('include', '/requirements')
      cy.get('#description').type('Se necesita un nuevo proyecto que implemente ecommerce para considerar los nuevos productos que estan saliendo al mercado')
      cy.contains('Actualizar Descripción del Proyecto').click()
      cy.get('button.bg-secondary.text-secondary-foreground').click()
  });
  // TC-19
  // TC-18
  it('handle generate requirements', () => {
    cy.visit('http://localhost:3000/login')
    cy.get('input[name="username"]').should('be.visible').type('poyo')
    cy.get('input[name="password"]').should('be.visible').type('poyoyon!')
    cy.get('button[type="submit"]').click()
    
    // Verificar login exitoso
    cy.url().should('include', '/dashboard')
    
    // Crear proyecto
    cy.get('.rounded-lg').contains('Crear Nuevo Proyecto').click()
    cy.get('#projName').type('Nombre del Proyecto')
    cy.get('#owner').type('Nombre del Propietario')
    
    // Seleccionar empresa
    cy.contains('Seleccionar empresa').click()
    cy.get('[role="option"]').first().click()
    
    // Seleccionar giro empresarial
    cy.contains('Seleccionar giro empresarial').click()
    cy.get('[role="option"]').first().click()
    
    cy.get('#budget').type(10000)
    cy.contains('button', 'Crear Proyecto').click()
    
    // Verificar redirección a requirements
    cy.url().should('include', '/requirements')
    
    // Actualizar descripción
    cy.get('#description')
      .type('Se necesita un nuevo proyecto que implemente ecommerce para considerar los nuevos productos que estan saliendo al mercado')
    cy.contains('Actualizar Descripción del Proyecto').click()
    
    // Click en generar con IA y manejar posibles errores
    cy.get('button.bg-secondary.text-secondary-foreground')
      .click()
      .then(() => {
        // Verificar si aparece mensaje de error
        cy.get('body').then($body => {
          if ($body.find('.error-message').length > 0) {
            // Si hay mensaje de error, verificarlo
            cy.get('.error-message')
              .should('be.visible')
              .then($error => {
                // Log del error para debugging
                cy.log('Error encontrado:', $error.text())
              })
          } else {
            // Si no hay error, verificar que se generaron los requerimientos
            cy.get('[data-testid="requirements-list"]', { timeout: 10000 })
              .should('exist')
              .and('be.visible')
          }
        })
      })

    // Verificar estado después de la generación
    cy.get('body').then($body => {
      if ($body.find('.success-message').length > 0) {
        cy.get('.success-message')
          .should('be.visible')
          .and('contain', 'Requerimientos generados exitosamente')
      }

      // Verificar que no haya errores de servidor
      cy.get('.error-toast')
        .should('not.exist')
    })
  })
  it('handle generate requirements when AI service is offline', () => {
    // Interceptar la llamada al servicio de IA y simular error
    cy.intercept('POST', '**/api/generate-requirements', {
      statusCode: 503,
      body: {
        error: 'Service Unavailable',
        message: 'El servicio de IA no está disponible en este momento'
      }
    }).as('generateRequirements')
  
    // Login
    cy.visit('http://localhost:3000/login')
    cy.get('input[name="username"]').should('be.visible').type('poyo')
    cy.get('input[name="password"]').should('be.visible').type('poyoyon!')
    cy.get('button[type="submit"]').click()
    
    // Verificar login exitoso
    cy.url().should('include', '/dashboard')
    
    // Crear proyecto
    cy.get('.rounded-lg').contains('Crear Nuevo Proyecto').click()
    cy.get('#projName').type('Nombre del Proyecto')
    cy.get('#owner').type('Nombre del Propietario')
    
    // Seleccionar empresa
    cy.contains('Seleccionar empresa').click()
    cy.get('[role="option"]').first().click()
    
    // Seleccionar giro empresarial
    cy.contains('Seleccionar giro empresarial').click()
    cy.get('[role="option"]').first().click()
    
    cy.get('#budget').type(10000)
    cy.contains('button', 'Crear Proyecto').click()
    
    // Verificar redirección a requirements
    cy.url().should('include', '/requirements')
    
    // Actualizar descripción
    cy.get('#description')
      .type('Se necesita un nuevo proyecto que implemente ecommerce para considerar los nuevos productos que estan saliendo al mercado')
    cy.contains('Actualizar Descripción del Proyecto').click()
    
    // Click en generar con IA
    cy.get('button.bg-secondary.text-secondary-foreground').click()
  
    // Esperar la llamada al servicio y verificar el error
    cy.wait('@generateRequirements')
      .its('response.statusCode')
      .should('eq', 503)
  
    // Verificar que se muestra el mensaje de error
    cy.get('.error-message')
      .should('be.visible')
      .and('contain', 'El servicio de IA no está disponible')
  
    // Verificar que no se generaron requerimientos
    cy.get('[data-testid="requirements-list"]')
      .should('not.exist')
  
    // Verificar que el botón de generar sigue habilitado para reintentar
    cy.get('button.bg-secondary.text-secondary-foreground')
      .should('be.enabled')
  
    // Verificar que la descripción del proyecto se mantiene
    cy.get('#description')
      .should('have.value', 'Se necesita un nuevo proyecto que implemente ecommerce para considerar los nuevos productos que estan saliendo al mercado')
  })
  // TC-20
  it('handle generate requirements when AI service is offline', () => {
    // Interceptar la llamada al servicio de IA y simular error
    cy.intercept('POST', '**/api/generate-requirements', {
      statusCode: 503,
      body: {
        error: 'Service Unavailable',
        message: 'El servicio de IA no está disponible en este momento'
      }
    }).as('generateRequirements')
  
    // Login
    cy.visit('http://localhost:3000/login')
    cy.get('input[name="username"]').should('be.visible').type('poyo')
    cy.get('input[name="password"]').should('be.visible').type('poyoyon!')
    cy.get('button[type="submit"]').click()
    
    // Verificar login exitoso
    cy.url().should('include', '/dashboard')
    
    // Crear proyecto
    cy.get('.rounded-lg').contains('Crear Nuevo Proyecto').click()
    cy.get('#projName').type('Nombre del Proyecto')
    cy.get('#owner').type('Nombre del Propietario')
    
    // Seleccionar empresa
    cy.contains('Seleccionar empresa').click()
    cy.get('[role="option"]').first().click()
    
    // Seleccionar giro empresarial
    cy.contains('Seleccionar giro empresarial').click()
    cy.get('[role="option"]').first().click()
    
    cy.get('#budget').type(10000)
    cy.contains('button', 'Crear Proyecto').click()
    
    // Verificar redirección a requirements
    cy.url().should('include', '/requirements')
    
    // Actualizar descripción
    cy.get('#description')
      .type('Se necesita un nuevo proyecto que implemente ecommerce para considerar los nuevos productos que estan saliendo al mercado')
    cy.contains('Actualizar Descripción del Proyecto').click()
    
    // Click en generar con IA
    cy.get('button.bg-secondary.text-secondary-foreground').click()
  
    // Esperar la llamada al servicio y verificar el error
    cy.wait('@generateRequirements')
      .its('response.statusCode')
      .should('eq', 503)
  
    // Verificar que se muestra el mensaje de error
    cy.get('.error-message')
      .should('be.visible')
      .and('contain', 'El servicio de IA no está disponible')
  
    // Verificar que no se generaron requerimientos
    cy.get('[data-testid="requirements-list"]')
      .should('not.exist')
  
    // Verificar que el botón de generar sigue habilitado para reintentar
    cy.get('button.bg-secondary.text-secondary-foreground')
      .should('be.enabled')
  
    // Verificar que la descripción del proyecto se mantiene
    cy.get('#description')
      .should('have.value', 'Se necesita un nuevo proyecto que implemente ecommerce para considerar los nuevos productos que estan saliendo al mercado')
  })
  // TC-21
it('handle task generation without requirements', () => {
  // Login
  cy.visit('http://localhost:3000/login')
  cy.get('input[name="username"]').should('be.visible').type('poyo')
  cy.get('input[name="password"]').should('be.visible').type('poyoyon!')
  cy.get('button[type="submit"]').click()
  
  // Verificar login exitoso
  cy.url().should('include', '/dashboard')
  
  // Crear proyecto
  cy.get('.rounded-lg').contains('Crear Nuevo Proyecto').click()
  cy.get('#projName').type('Nombre del Proyecto')
  cy.get('#owner').type('Nombre del Propietario')
  
  // Seleccionar empresa
  cy.contains('Seleccionar empresa').click()
  cy.get('[role="option"]').first().click()
  
  // Seleccionar giro empresarial
  cy.contains('Seleccionar giro empresarial').click()
  cy.get('[role="option"]').first().click()
  
  cy.get('#budget').type(10000)
  cy.contains('button', 'Crear Proyecto').click()

  // Verificar que estamos en la página del proyecto
  cy.url().should('include', '/requirements')

  // Verificar que no hay requerimientos
  cy.get('[data-testid="requirements-list"]')
    .should('not.exist')
    .or('be.empty')

  // 2. Intentar generar tareas
  cy.contains('Generar tareas').click()

  // 3. Verificar mensaje de error
  cy.get('.error-message')
    .should('be.visible')
    .and('contain', 'No se pueden generar tareas sin requerimientos definidos')

  // Verificar que el botón de generar tareas está deshabilitado o muestra un tooltip
  cy.contains('button', 'Generar tareas')
    .should('be.disabled')
    .or('have.attr', 'title', 'Necesitas definir requerimientos primero')

  // Verificar que se mantiene en la misma página
  cy.url().should('include', '/requirements')

  // Verificar que se muestra alguna indicación de cómo proceder
  cy.get('.info-message')
    .should('contain', 'Primero debes definir los requerimientos del proyecto')
})
  // TC-22
  it('handle manual requirement creation', () => {
    // Login
    cy.visit('http://localhost:3000/login')
    cy.get('input[name="username"]').should('be.visible').type('poyo')
    cy.get('input[name="password"]').should('be.visible').type('poyoyon!')
    cy.get('button[type="submit"]').click()
    
    // Verificar login exitoso
    cy.url().should('include', '/dashboard')
    
    // Crear proyecto
    cy.get('.rounded-lg').contains('Crear Nuevo Proyecto').click()
    cy.get('#projName').type('Nombre del Proyecto')
    cy.get('#owner').type('Nombre del Propietario')
    
    // Seleccionar empresa
    cy.contains('Seleccionar empresa').click()
    cy.get('[role="option"]').first().click()
    
    // Seleccionar giro empresarial
    cy.contains('Seleccionar giro empresarial').click()
    cy.get('[role="option"]').first().click()
    
    cy.get('#budget').type(10000)
    cy.contains('button', 'Crear Proyecto').click()
    
    // Verificar redirección a requirements
    cy.url().should('include', '/requirements')

    // 2. Verificar que estamos en la sección de requerimientos
    cy.contains('Requerimientos').should('be.visible')

    // 3. Crear requerimiento manual
    cy.get('#newRequirement')
      .should('be.visible')
      .type('El sistema debe permitir la gestión de usuarios')

    // Click en botón de agregar
    cy.contains('button', 'Agregar').click()

    // Verificaciones
    // Verificar que el requerimiento aparece en la lista
    cy.get('[data-testid="requirements-list"]')
      .should('be.visible')
      .and('contain', 'El sistema debe permitir la gestión de usuarios')

    // Verificar que el input se limpió
    cy.get('#newRequirement')
      .should('have.value', '')

    // Verificar que se puede agregar otro requerimiento
    cy.get('#newRequirement')
      .type('El sistema debe ser responsive')
    cy.contains('button', 'Agregar').click()

    // Verificar que ambos requerimientos existen
    cy.get('[data-testid="requirements-list"]')
      .should('contain', 'El sistema debe permitir la gestión de usuarios')
      .and('contain', 'El sistema debe ser responsive')

    // Verificar contador de requerimientos si existe
    cy.get('[data-testid="requirements-count"]')
      .should('contain', '2')
  })
  // TC-23
  it('handle framework contract generation without associated company', () => {
    // Login
    cy.visit('http://localhost:3000/login')
    cy.get('input[name="username"]').should('be.visible').type('poyo')
    cy.get('input[name="password"]').should('be.visible').type('poyoyon!')
    cy.get('button[type="submit"]').click()
    
    // Verificar login exitoso
    cy.url().should('include', '/dashboard')
    
    // Crear proyecto sin empresa asociada
    cy.get('.rounded-lg').contains('Crear Nuevo Proyecto').click()
    cy.get('#projName').type('Proyecto Sin Empresa')
    cy.get('#owner').type('Nombre del Propietario')
    cy.get('#budget').type(10000)
    
    // Saltamos la selección de empresa intencionalmente
    
    // Seleccionar giro empresarial
    cy.contains('Seleccionar giro empresarial').click()
    cy.get('[role="option"]').first().click()
    
    cy.contains('button', 'Crear Proyecto').click()

    // 1. Acceder al proyecto
    cy.url().should('include', '/requirements')

    // 2. Intentar generar contrato marco
    cy.contains('Generar contrato marco').click()

    // Verificar que aparece mensaje de error
    cy.get('.error-message')
      .should('be.visible')
      .and('contain', 'No se puede generar el contrato marco sin una empresa asociada')

    // Verificar que el botón está deshabilitado o muestra advertencia
    cy.contains('button', 'Generar contrato marco')
      .should('be.disabled')
      .or('have.attr', 'title', 'Necesitas asociar una empresa primero')

    // Verificar que no se generó ningún contrato
    cy.get('[data-testid="contract-preview"]')
      .should('not.exist')

    // Verificar que se muestra indicación de cómo proceder
    cy.get('.info-message')
      .should('be.visible')
      .and('contain', 'Asocia una empresa al proyecto para poder generar el contrato marco')

    // Verificar que permanecemos en la misma página
    cy.url().should('not.include', '/contract')

    // Opcional: Verificar que se muestra un enlace para asociar empresa
    cy.contains('Asociar empresa')
      .should('be.visible')
      .and('have.attr', 'href')
  })
  // TC-24
  it('handle framework contract generation with incomplete client data', () => {
    // Login
    cy.visit('http://localhost:3000/login')
    cy.get('input[name="username"]').should('be.visible').type('poyo')
    cy.get('input[name="password"]').should('be.visible').type('poyoyon!')
    cy.get('button[type="submit"]').click()
    
    // Verificar login exitoso
    cy.url().should('include', '/dashboard')
    
    // Crear proyecto con datos incompletos
    cy.get('.rounded-lg').contains('Crear Nuevo Proyecto').click()
    cy.get('#projName').type('Proyecto Test')
    cy.get('#owner').type('Nombre del Propietario')
    
    // Seleccionar empresa (con datos incompletos)
    cy.contains('Seleccionar empresa').click()
    cy.get('[role="option"]').first().click()
    
    // Seleccionar giro empresarial
    cy.contains('Seleccionar giro empresarial').click()
    cy.get('[role="option"]').first().click()
    
    cy.get('#budget').type(10000)
    cy.contains('button', 'Crear Proyecto').click()

    // 1. Acceder al proyecto
    cy.url().should('include', '/requirements')

    // 2. Intentar generar contrato marco
    cy.contains('Generar contrato marco').click()

    // 3. Verificar mensajes de error por datos faltantes
    cy.get('.error-message')
      .should('be.visible')
      .and('contain', 'Faltan datos requeridos del cliente')

    // Verificar lista específica de datos faltantes
    cy.get('.missing-data-list')
      .should('contain', 'Dirección del cliente')
      .and('contain', 'RFC')
      .and('contain', 'Representante legal')

    // Verificar que el botón está deshabilitado o muestra advertencia
    cy.contains('button', 'Generar contrato marco')
      .should('be.disabled')
      .or('have.attr', 'title', 'Completa los datos del cliente')

    // Verificar que no se generó ningún contrato
    cy.get('[data-testid="contract-preview"]')
      .should('not.exist')

    // Verificar que se muestra indicación de cómo proceder
    cy.get('.info-message')
      .should('be.visible')
      .and('contain', 'Completa todos los datos del cliente para poder generar el contrato marco')

    // Opcional: Verificar que se muestra enlace para completar datos
    cy.contains('Completar datos del cliente')
      .should('be.visible')
      .and('have.attr', 'href')

    // Verificar que permanecemos en la misma página
    cy.url().should('not.include', '/contract')
  })
  // TC-25
  it('handle requirements generation without project description', () => {
    // Login
    cy.visit('http://localhost:3000/login')
    cy.get('input[name="username"]').should('be.visible').type('poyo')
    cy.get('input[name="password"]').should('be.visible').type('poyoyon!')
    cy.get('button[type="submit"]').click()
    
    // Verificar login exitoso
    cy.url().should('include', '/dashboard')
    
    // Crear proyecto
    cy.get('.rounded-lg').contains('Crear Nuevo Proyecto').click()
    cy.get('#projName').type('Proyecto Test')
    cy.get('#owner').type('Nombre del Propietario')
    
    // Seleccionar empresa
    cy.contains('Seleccionar empresa').click()
    cy.get('[role="option"]').first().click()
    
    // Seleccionar giro empresarial
    cy.contains('Seleccionar giro empresarial').click()
    cy.get('[role="option"]').first().click()
    
    cy.get('#budget').type(10000)
    cy.contains('button', 'Crear Proyecto').click()

    // Verificar que estamos en la página de requerimientos
    cy.url().should('include', '/requirements')

    // 1. Verificar que la descripción está vacía
    cy.get('#description')
      .should('be.visible')
      .and('have.value', '')

    // 2. Intentar generar requerimientos con IA
    cy.get('button.bg-secondary.text-secondary-foreground').click()

    // 3. Verificar mensaje de error
    cy.get('.error-message')
      .should('be.visible')
      .and('contain', 'No se pueden generar requerimientos sin una descripción del proyecto')

    // Verificar que el botón está deshabilitado o muestra advertencia
    cy.get('button.bg-secondary.text-secondary-foreground')
      .should('be.disabled')
      .or('have.attr', 'title', 'Ingrese una descripción del proyecto')

    // Verificar que no se generaron requerimientos
    cy.get('[data-testid="requirements-list"]')
      .should('not.exist')
      .or('be.empty')

    // Verificar que se mantiene en la misma página
    cy.url().should('include', '/requirements')

    // Verificar que se muestra indicación de cómo proceder
    cy.get('.info-message')
      .should('be.visible')
      .and('contain', 'Ingrese una descripción del proyecto para generar requerimientos')

    // Verificar que el campo de descripción está resaltado o marcado como requerido
    cy.get('#description')
      .should('have.class', 'error')
      .or('have.attr', 'aria-invalid', 'true')
  })
  // TC-26
  it('handle requirements generation after modifying project characteristics', () => {
    // Login
    cy.visit('http://localhost:3000/login')
    cy.get('input[name="username"]').should('be.visible').type('poyo')
    cy.get('input[name="password"]').should('be.visible').type('poyoyon!')
    cy.get('button[type="submit"]').click()
    
    // Verificar login exitoso
    cy.url().should('include', '/dashboard')
    
    // Crear proyecto con características iniciales
    cy.get('.rounded-lg').contains('Crear Nuevo Proyecto').click()
    cy.get('#projName').type('Proyecto Test')
    cy.get('#owner').type('Nombre del Propietario')
    
    // Seleccionar empresa
    cy.contains('Seleccionar empresa').click()
    cy.get('[role="option"]').first().click()
    
    // Seleccionar giro empresarial
    cy.contains('Seleccionar giro empresarial').click()
    cy.get('[role="option"]').first().click()
    
    cy.get('#budget').type(10000)

    // Agregar descripción inicial
    cy.get('#description')
      .type('Sistema de gestión de inventarios básico')

    cy.contains('button', 'Crear Proyecto').click()

    // Generar requerimientos iniciales
    cy.get('button.bg-secondary.text-secondary-foreground').click()

    // Esperar a que se generen los requerimientos iniciales
    cy.get('[data-testid="requirements-list"]')
      .should('be.visible')
      .as('initialRequirements')

    // Guardar los requerimientos iniciales para comparar después
    cy.get('[data-testid="requirements-list"]').invoke('text').as('oldRequirements')

    // 1. Modificar características del proyecto
    cy.get('#description')
      .clear()
      .type('Sistema de gestión de inventarios avanzado con módulo de predicción de demanda y alertas automáticas')

    // Actualizar descripción
    cy.contains('Actualizar Descripción del Proyecto').click()

    // Verificar que se guardó la actualización
    cy.get('.success-message')
      .should('contain', 'Descripción actualizada correctamente')

    // 2. Generar nuevos requerimientos con IA
    cy.get('button.bg-secondary.text-secondary-foreground').click()

    // 3. Confirmar la generación
    cy.get('[data-testid="confirmation-modal"]')
      .should('be.visible')
      .within(() => {
        cy.contains('button', 'Confirmar').click()
      })

    // Esperar a que se actualicen los requerimientos
    cy.get('[data-testid="loading-spinner"]').should('not.exist')

    // Verificar que los nuevos requerimientos son diferentes
    cy.get('[data-testid="requirements-list"]')
      .invoke('text')
      .then((newRequirements) => {
        cy.get('@oldRequirements').then((oldRequirements) => {
          expect(newRequirements).to.not.equal(oldRequirements)
        })
      })

    // Verificar que los nuevos requerimientos incluyen elementos relacionados con las nuevas características
    cy.get('[data-testid="requirements-list"]')
      .should('contain', 'predicción')
      .and('contain', 'alertas')

    // Verificar mensaje de éxito
    cy.get('.success-message')
      .should('be.visible')
      .and('contain', 'Requerimientos actualizados correctamente')

    // Verificar que los nuevos requerimientos están guardados
    cy.reload()
    cy.get('[data-testid="requirements-list"]')
      .should('contain', 'predicción')
      .and('contain', 'alertas')
  })
  // TC-27
  it('validate project name character limit', () => {
    // Login
    cy.visit('http://localhost:3000/login')
    cy.get('input[name="username"]').should('be.visible').type('poyo')
    cy.get('input[name="password"]').should('be.visible').type('poyoyon!')
    cy.get('button[type="submit"]').click()
    
    // Verificar login exitoso
    cy.url().should('include', '/dashboard')
    
    // 1. Ir a la sección de creación de proyecto
    cy.get('.rounded-lg').contains('Crear Nuevo Proyecto').click()

    // 2. Intentar ingresar un nombre demasiado largo
    const largeText = 'a'.repeat(1000) // Texto muy largo
    
    cy.get('#projName')
      .type(largeText)
      .invoke('val')
      .should('have.length.lte', 100) // Asumiendo un límite de 100 caracteres
    
    // Verificar que el campo tiene un atributo maxlength
    cy.get('#projName')
      .should('have.attr', 'maxlength')

    // Llenar los demás campos
    cy.get('#owner').type('Nombre del Propietario')
    
    // Seleccionar empresa
    cy.contains('Seleccionar empresa').click()
    cy.get('[role="option"]').first().click()
    
    // Seleccionar giro empresarial
    cy.contains('Seleccionar giro empresarial').click()
    cy.get('[role="option"]').first().click()
    
    cy.get('#budget').type(10000)

    // 3. Intentar guardar
    cy.contains('button', 'Crear Proyecto').click()

    // Verificar que el botón de guardar está habilitado 
    // (ya que el texto se truncó al máximo permitido)
    cy.contains('button', 'Crear Proyecto')
      .should('not.be.disabled')

    // Verificar que se muestra el contador de caracteres (si existe)
    cy.get('[data-testid="char-counter"]')
      .should('exist')
      .and('contain', '100/100') // Ajustar según el límite real

    // Verificar que el campo mantiene solo los caracteres permitidos
    cy.get('#projName')
      .invoke('val')
      .should('have.length.lte', 100)

    // Verificar que se muestra un tooltip o mensaje informativo
    cy.get('#projName')
      .trigger('mouseover')
    cy.get('.tooltip')
      .should('be.visible')
      .and('contain', 'Máximo 100 caracteres') // Ajustar según el mensaje real
  })
  // TC-28
  it('handle AI task generation when AI service is offline', () => {
    // Interceptar la llamada al servicio de IA y simular error de servicio caído
    cy.intercept('POST', '**/api/generate-tasks', {
      statusCode: 503,
      body: {
        error: 'Service Unavailable',
        message: 'El servicio de IA no está disponible en este momento'
      }
    }).as('generateTasks')

    // Login
    cy.visit('http://localhost:3000/login')
    cy.get('input[name="username"]').should('be.visible').type('poyo')
    cy.get('input[name="password"]').should('be.visible').type('poyoyon!')
    cy.get('button[type="submit"]').click()
    
    // Verificar login exitoso
    cy.url().should('include', '/dashboard')
    
    // Crear proyecto con requerimientos
    cy.get('.rounded-lg').contains('Crear Nuevo Proyecto').click()
    cy.get('#projName').type('Proyecto Test')
    cy.get('#owner').type('Nombre del Propietario')
    
    // Seleccionar empresa
    cy.contains('Seleccionar empresa').click()
    cy.get('[role="option"]').first().click()
    
    // Seleccionar giro empresarial
    cy.contains('Seleccionar giro empresarial').click()
    cy.get('[role="option"]').first().click()
    
    cy.get('#budget').type(10000)
    cy.contains('button', 'Crear Proyecto').click()

    // 1. Acceder al proyecto (ya estamos en él)
    cy.url().should('include', '/requirements')

    // Agregar algunos requerimientos (necesarios para generar tareas)
    cy.get('#description')
      .type('Sistema de gestión de inventarios')
    cy.contains('Actualizar Descripción del Proyecto').click()

    // 2. Intentar generar tareas con IA
    cy.contains('Generar con IA').click()

    // 3. Confirmar en el modal (si existe)
    cy.get('[data-testid="confirmation-modal"]')
      .should('be.visible')
      .within(() => {
        cy.contains('button', 'Confirmar').click()
      })

    // Esperar la respuesta del servicio caído
    cy.wait('@generateTasks')
      .its('response.statusCode')
      .should('eq', 503)

    // Verificar mensaje de error
    cy.get('.error-message')
      .should('be.visible')
      .and('contain', 'El servicio de IA no está disponible')

    // Verificar que no se generaron tareas
    cy.get('[data-testid="tasks-list"]')
      .should('not.exist')
      .or('be.empty')

    // Verificar que el botón de generar sigue habilitado para reintentar
    cy.contains('Generar con IA')
      .should('be.enabled')

    // Verificar que se muestra sugerencia de reintento
    cy.get('.info-message')
      .should('contain', 'Por favor, intente nuevamente más tarde')

    // Verificar que permanecemos en la misma página
    cy.url().should('include', '/requirements')

    // Verificar que se muestra opción de generación manual
    cy.contains('Crear tarea manualmente')
      .should('be.visible')
  })
  // TC-29
  it('handle AI contract generation when AI service is offline', () => {
    // Interceptar la llamada al servicio de IA y simular error de servicio caído
    cy.intercept('POST', '**/api/generate-contract', {
      statusCode: 503,
      body: {
        error: 'Service Unavailable',
        message: 'El servicio de IA no está disponible en este momento'
      }
    }).as('generateContract')

    // Login
    cy.visit('http://localhost:3000/login')
    cy.get('input[name="username"]').should('be.visible').type('poyo')
    cy.get('input[name="password"]').should('be.visible').type('poyoyon!')
    cy.get('button[type="submit"]').click()
    
    // Verificar login exitoso
    cy.url().should('include', '/dashboard')
    
    // Crear proyecto con datos necesarios para el contrato
    cy.get('.rounded-lg').contains('Crear Nuevo Proyecto').click()
    cy.get('#projName').type('Proyecto Test')
    cy.get('#owner').type('Nombre del Propietario')
    
    // Seleccionar empresa
    cy.contains('Seleccionar empresa').click()
    cy.get('[role="option"]').first().click()
    
    // Seleccionar giro empresarial
    cy.contains('Seleccionar giro empresarial').click()
    cy.get('[role="option"]').first().click()
    
    cy.get('#budget').type(10000)
    cy.contains('button', 'Crear Proyecto').click()

    // 1. Acceder al proyecto y sus contratos
    cy.contains('Contratos').click()
    cy.url().should('include', '/contracts')

    // 2. Intentar generar contrato con IA
    cy.contains('Generar con IA').click()

    // 3. Confirmar en el modal
    cy.get('[data-testid="confirmation-modal"]')
      .should('be.visible')
      .within(() => {
        cy.contains('button', 'Confirmar').click()
      })

    // Esperar la respuesta del servicio caído
    cy.wait('@generateContract')
      .its('response.statusCode')
      .should('eq', 503)

    // Verificar mensaje de error apropiado
    cy.get('.error-message')
      .should('be.visible')
      .and('contain', 'El servicio de IA no está disponible')

    // Verificar que no se generó el contrato
    cy.get('[data-testid="contract-preview"]')
      .should('not.exist')

    // Verificar que el botón de generar sigue habilitado para reintentar
    cy.contains('Generar con IA')
      .should('be.enabled')

    // Verificar que se muestra sugerencia de reintento
    cy.get('.info-message')
      .should('be.visible')
      .and('contain', 'Por favor, intente nuevamente más tarde')

    // Verificar que se muestra opción de usar plantilla manual
    cy.contains('Usar plantilla manual')
      .should('be.visible')

    // Verificar que el spinner de carga desaparece
    cy.get('[data-testid="loading-spinner"]')
      .should('not.exist')

    // Verificar que permanecemos en la misma página
    cy.url().should('include', '/contracts')
  })
})