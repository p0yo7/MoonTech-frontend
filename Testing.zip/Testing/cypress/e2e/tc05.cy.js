describe('template spec', () => {
  // TC-19
it('handle generate requirements when AI service is offline', () => {
  // Interceptar la llamada al servicio de IA y simular error
  cy.intercept('POST', '**/api/generate-requirements', {
    statusCode: 503,
    body: {
      error: 'Service Unavailable',
      message: 'El servicio de IA no está disponible en este momento'
    }
  }).as('generateRequirements')

  // Login
  cy.visit('http://localhost:3000/login')
  cy.get('input[name="username"]').should('be.visible').type('poyo')
  cy.get('input[name="password"]').should('be.visible').type('poyoyon!')
  cy.get('button[type="submit"]').click()
  
  // Verificar login exitoso
  cy.url().should('include', '/dashboard')
  
  // Crear proyecto
  cy.get('.rounded-lg').contains('Crear Nuevo Proyecto').click()
  cy.get('#projName').type('Nombre del Proyecto')
  cy.get('#owner').type('Nombre del Propietario')
  
  // Seleccionar empresa
  cy.contains('Seleccionar empresa').click()
  cy.get('[role="option"]').first().click()
  
  // Seleccionar giro empresarial
  cy.contains('Seleccionar giro empresarial').click()
  cy.get('[role="option"]').first().click()
  
  cy.get('#budget').type(10000)
  cy.contains('button', 'Crear Proyecto').click()
  
  // Verificar redirección a requirements
  cy.url().should('include', '/requirements')
  
  // Actualizar descripción
  cy.get('#description')
    .type('Se necesita un nuevo proyecto que implemente ecommerce para considerar los nuevos productos que estan saliendo al mercado')
  cy.contains('Actualizar Descripción del Proyecto').click()
  
  // Click en generar con IA
  cy.get('button.bg-secondary.text-secondary-foreground').click()

  // Esperar la llamada al servicio y verificar el error
  cy.wait('@generateRequirements')
    .its('response.statusCode')
    .should('eq', 503)

  // Verificar que se muestra el mensaje de error
  cy.get('.error-message')
    .should('be.visible')
    .and('contain', 'El servicio de IA no está disponible')

  // Verificar que no se generaron requerimientos
  cy.get('[data-testid="requirements-list"]')
    .should('not.exist')

  // Verificar que el botón de generar sigue habilitado para reintentar
  cy.get('button.bg-secondary.text-secondary-foreground')
    .should('be.enabled')

  // Verificar que la descripción del proyecto se mantiene
  cy.get('#description')
    .should('have.value', 'Se necesita un nuevo proyecto que implemente ecommerce para considerar los nuevos productos que estan saliendo al mercado')
})
})
describe('Oracle Cloud Integration Tests', () => {
  beforeEach(() => {
    // Login
    cy.visit('http://localhost:3000/login')
    cy.get('input[name="username"]').should('be.visible').type('poyo')
    cy.get('input[name="password"]').should('be.visible').type('poyoyon!')
    cy.get('button[type="submit"]').click()
  })

  it('TC-30 - validate Oracle Cloud connection - Success Case', () => {
    // Simular respuesta exitosa de Oracle Cloud
    cy.intercept('GET', '**/api/oracle-cloud/status', {
      statusCode: 200,
      body: {
        status: 'connected',
        message: 'Conexión establecida correctamente'
      }
    }).as('connectionStatus')

    // 1. Acceder a la sección de configuración
    cy.contains('Configuración').click()
    cy.url().should('include', '/settings')

    // 2. Intentar generar datos
    cy.contains('Generar Datos').click()

    // Esperar respuesta de la conexión
    cy.wait('@connectionStatus')

    // 3. Verificar estado de conexión
    cy.get('[data-testid="connection-status"]')
      .should('be.visible')
      .and('contain', 'Conectado')
      .and('have.class', 'connected')

    // Verificar que los datos se generan correctamente
    cy.get('[data-testid="generated-data"]')
      .should('be.visible')
  })

  it('TC-30 - validate Oracle Cloud connection - Failed Case', () => {
    // Simular respuesta fallida de Oracle Cloud
    cy.intercept('GET', '**/api/oracle-cloud/status', {
      statusCode: 503,
      body: {
        status: 'error',
        message: 'Error: No se pudo conectar con Oracle Cloud'
      }
    }).as('connectionStatus')

    // 1. Acceder a la sección de configuración
    cy.contains('Configuración').click()
    cy.url().should('include', '/settings')

    // 2. Intentar generar datos
    cy.contains('Generar Datos').click()

    // Esperar respuesta de la conexión
    cy.wait('@connectionStatus')

    // 3. Verificar estado de conexión
    cy.get('[data-testid="connection-status"]')
      .should('be.visible')
      .and('contain', 'Desconectado')
      .and('have.class', 'disconnected')

    // Verificar mensaje de error
    cy.get('.error-message')
      .should('be.visible')
      .and('contain', 'Error: No se pudo conectar con Oracle Cloud')

    // Verificar que los datos no se generan
    cy.get('[data-testid="generated-data"]')
      .should('not.exist')

    // Verificar que se muestra opción de reintentar
    cy.contains('Reintentar conexión')
      .should('be.visible')
      .and('be.enabled')

    // Verificar indicadores visuales de estado
    cy.get('[data-testid="status-indicator"]')
      .should('have.class', 'error')
  })

  it('TC-30 - validate Oracle Cloud reconnection attempt', () => {
    // Simular primera respuesta fallida
    cy.intercept('GET', '**/api/oracle-cloud/status', {
      statusCode: 503,
      body: {
        status: 'error',
        message: 'Error: No se pudo conectar con Oracle Cloud'
      }
    }).as('failedConnection')

    // 1. Acceder a la configuración
    cy.contains('Configuración').click()

    // 2. Intentar generar datos
    cy.contains('Generar Datos').click()

    // Esperar respuesta fallida
    cy.wait('@failedConnection')

    // Simular reconexión exitosa
    cy.intercept('POST', '**/api/oracle-cloud/reconnect', {
      statusCode: 200,
      body: {
        status: 'connected',
        message: 'Conexión reestablecida correctamente'
      }
    }).as('reconnection')

    // Intentar reconexión
    cy.contains('Reintentar conexión').click()

    // Verificar reconexión exitosa
    cy.wait('@reconnection')
    cy.get('[data-testid="connection-status"]')
      .should('contain', 'Conectado')

    // Verificar que ahora se pueden generar datos
    cy.contains('Generar Datos').click()
    cy.get('[data-testid="generated-data"]')
      .should('be.visible')
  })
})