describe('Login Functionality', () => {
  beforeEach(() => {
    // Configurar Cypress para usar modo incógnito
    Cypress.Commands.add('visitInIncognito', (url) => {
      cy.visit(url, {
        onBeforeLoad: (win) => {
          win.sessionStorage.clear()
          win.localStorage.clear()
        }
      })
    })
    
    // Visitar la página de login en modo incógnito
    cy.visitInIncognito('http://localhost:3000/login')
  })

  it('TC-09 - Login exitoso desde modo incógnito', () => {
    // Interceptar la solicitud de login
    cy.intercept('POST', 'http://localhost:8080/login/native').as('loginRequest')

    // 1. Ingresar los datos correctos del usuario
    cy.get('input[name="username"]').type('poyo')
    cy.get('input[name="password"]').type('poyoyon!')

    // 2. Dar click en el botón de login
    cy.get('button[type="submit"]').click()

    // Esperar la respuesta del servidor
    cy.wait('@loginRequest').then((interception) => {
      // Verificar que la solicitud fue exitosa
      expect(interception.response.statusCode).to.eq(200)
    })

    // Verificar redirección al menú principal
    cy.url().should('include', '/dashboard')

  })

  // Test cases adicionales para validar comportamiento en modo incógnito
  it('verifica que no existan datos previos en modo incógnito', () => {
    // Verificar que localStorage y sessionStorage estén vacíos
    cy.window().then((win) => {
      expect(win.localStorage.length).to.eq(0)
      expect(win.sessionStorage.length).to.eq(0)
    })
  })

  it('mantiene el estado de incógnito después de cerrar sesión', () => {
    // Realizar login
    cy.get('input[name="username"]').type('poyo')
    cy.get('input[name="password"]').type('poyoyon!')
    cy.get('button[type="submit"]').click()

    // Cerrar sesión
    // cy.get('.logout-button').click()

    // Verificar que no queden datos en el storage
    cy.window().then((win) => {
      expect(win.localStorage.length).to.eq(0)
      expect(win.sessionStorage.length).to.eq(0)
    })

    // Verificar redirección a la página de login
    cy.url().should('include', '/login')
  })
})