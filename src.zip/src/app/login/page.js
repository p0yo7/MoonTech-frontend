"use client"; 

import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "./globals.css";
import videoBackground from '../../assets/animationone.mp4'; // Aquí va tu animación

export default function Login() {
  const navigate = useNavigate();
  const [showLogin, setShowLogin] = useState(false);

  useEffect(() => {
    // Mostrar la caja de login después de 1 segundo
    const timer = setTimeout(() => setShowLogin(true), 1000);
    return () => clearTimeout(timer);
  }, []);

  const handleLogin = () => {
    const username = document.querySelector('input[type="text"]').value;
    const password = document.querySelector('input[type="password"]').value;

    // Validar credenciales
    if (username === "MoonTech" && password === "1234") {
      navigate('/menu');
    } else {
      alert('Credenciales incorrectas');
    }
  };

  return (
    <div className="login-page">
      {/* Video de fondo */}
      <video autoPlay loop muted className="background-video">
        <source src={videoBackground} type="video/mp4" />
      </video>

      {/* Caja de login */}
      <div className={`container ${showLogin ? 'slide-in' : ''}`}>
        <h1>NEORIS x SAGE</h1>

        <div className="input-container">
          <input type="text" placeholder="Username" />
          <input type="password" placeholder="Password" />
        </div>

        <button className="login-button" onClick={handleLogin}>Login</button>

        <div className="auth-buttons">
          <div className="auth-button">
            <img src="https://upload.wikimedia.org/wikipedia/commons/4/44/Microsoft_logo.svg" alt="Microsoft Auth" />
          </div>
          <div className="auth-button">
            <img src="https://upload.wikimedia.org/wikipedia/commons/5/53/Google_%22G%22_Logo.svg" alt="Google Auth" />
          </div>
        </div>

        <div className="logo-container">
          <img src="../../assets/moontech.png" alt="Moontech logo" />
        </div>
      </div>
    </div>
  );
}
