"use client";
import React from "react";
import { useNavigate } from "react-router-dom"; // Para la navegación entre páginas
import Image from 'next/image';
import owlImage from '../../assets/neo.png'; // Importa la imagen del búho
import neorisSageImage from '../../assets/neoris-sage.png'; // Importa la imagen para "Neoris x Sage"
import nuImage from '../../assets/nu.png'; // Imagen del proyecto Nu
import cemexImage from '../../assets/cemex.png'; // Imagen del proyecto Cemex
import brandImage from '../../assets/brand.png'; // Imagen del proyecto Brand
import "./globals.css"; // Estilos

const MenuPage = () => {
  const navigate = useNavigate(); // Hook para redirigir

  return (
    <div className="menu-container">
      {/* Pestaña lateral gris */}
      <div className="sidebar">
        <Image src={neorisSageImage} alt="Neoris x Sage" className="sidebar-logo" /> {/* Imagen de NEORIS x SAGE */}
        <div className="sidebar-links">
          <button onClick={() => navigate("/menu")} className="sidebar-button">
            <i className="icon-dashboard"></i> Dashboard
          </button>
          <button onClick={() => navigate("/kanban")} className="sidebar-button">
            <i className="icon-kanban"></i> Kanban
          </button>
          <button onClick={() => navigate("/notifications")} className="sidebar-button">
            <i className="icon-notifications"></i> Notifications
          </button>
          <button onClick={() => navigate("/settings")} className="sidebar-button">
            <i className="icon-settings"></i> Settings
          </button>
          <button onClick={() => navigate("/login")} className="sidebar-button">
            <i className="icon-logout"></i> Log out
          </button>
        </div>
      </div>

      {/* Contenedor principal */}
      <div className="main-content">
        <div className="header">
          <h2>Welcome, Edward Altamirano</h2>
          <p className="subheader">Your projects</p>
        </div>

        {/* Sección de proyectos con scrollbar */}
        <div className="projects-section">
          <button onClick={() => navigate("/project")} className="project-card">
            <Image src={nuImage} alt="Nu Project" className="project-image" />
          </button>
          <button onClick={() => navigate("/project")} className="project-card">
            <Image src={cemexImage} alt="Cemex Project" className="project-image" />
          </button>
          <button onClick={() => navigate("/project")} className="project-card">
            <Image src={brandImage} alt="Brand Project" className="project-image" />
          </button>
          <button onClick={() => navigate("/newproject")} className="project-card">
            <div className="add-project">+</div>
          </button>
        </div>

        {/* Botón para crear nuevo proyecto */}
        <div className="new-project-button">
          <button onClick={() => navigate("/newproject")}>Create New Project</button>
        </div>
      </div>

      {/* Pestaña lateral derecha con texto y búho */}
      <div className="right-sidebar">
        <p className="helper-text">
          Hi! I'm Neo, we are working together from now and I will always be here to help you with whatever you need. <br/><br/>
          Please, let's do a great job together! <br/><br/>
          -Best regards, Neo.
        </p>
        <Image src={owlImage} alt="Owl" className="owl-image" /> {/* Imagen del búho */}
      </div>
    </div>
  );
};

export default MenuPage;
