"use client";
import React, { useState } from "react";
import Image from 'next/image';
import owlImage from '../../assets/neo.png'; // Imagen del búho
import "./globals.css"; // Estilos globales

const NuevoProyecto = () => {
  // Estados
  const [step, setStep] = useState(1); // Control del paso actual
  const [title, setTitle] = useState(""); // Título del proyecto
  const [requirements, setRequirements] = useState([]); // Lista de requerimientos
  const [requirementInput, setRequirementInput] = useState(""); // Campo de entrada para requerimientos
  const [teamMembers, setTeamMembers] = useState([]); // Miembros del equipo seleccionados
  const [teamInput, setTeamInput] = useState(""); // Campo de entrada para buscar miembros
  const [headerText, setHeaderText] = useState("Let’s crate a new project!"); // Texto arriba del búho

  // Función para actualizar el título
  const handleTitleSubmit = () => {
    if (title.trim() !== "") {
      setStep(2); // Pasar al siguiente paso
      setHeaderText("What are the needs of this project?"); // Actualizar texto del búho
    }
  };

  // Función para añadir un requerimiento
  const handleAddRequirement = () => {
    if (requirementInput.trim() !== "") {
      setRequirements([...requirements, requirementInput]);
      setRequirementInput(""); // Limpiar el campo de entrada
    }
  };

  // Función para pasar al siguiente paso después de añadir requerimientos
  const handleRequirementsSubmit = () => {
    if (requirements.length > 0) {
      setStep(3); // Pasar al paso 3
      setHeaderText("Who’s working on this project?"); // Actualizar texto del búho
    }
  };

  // Función para añadir un miembro del equipo
  const handleAddTeamMember = (member) => {
    if (!teamMembers.includes(member)) {
      setTeamMembers([...teamMembers, member]);
    }
  };

  // Función para finalizar la creación del proyecto
  const handleFinalStep = () => {
    setStep(4); // Paso final
    setHeaderText("Almost there! Ready to start?"); // Actualizar texto del búho
  };

  return (
    <div className="new-project-container">
      {/* Texto y búho fuera del popup */}
      <div className="header-text">
        <p>{headerText}</p>
      </div>
      <div className="owl-container">
        <Image src={owlImage} alt="Owl" className="owl-image" /> {/* Imagen del búho */}
      </div>

      {/* Pop-up */}
      <div className="popup">
        <div className="close-icon" onClick={() => console.log("Cerrar popup")}>✕</div> {/* Ícono de cierre */}
        
        {/* Paso 1: Ingresar el título */}
        {step === 1 && (
          <div className="step-content">
            <h2>Write down your title</h2>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="input-field"
              placeholder="Enter project title"
            />
            <button className="arrow-button" onClick={handleTitleSubmit}>➔</button> {/* Botón de flecha */}
          </div>
        )}

        {/* Paso 2: Ingresar los requerimientos */}
        {step === 2 && (
          <div className="step-content">
            <h2>Enter your requirements</h2>
            <input
              type="text"
              value={requirementInput}
              onChange={(e) => setRequirementInput(e.target.value)}
              className="input-field"
              placeholder="Enter a requirement"
            />
            <button className="add-button" onClick={handleAddRequirement}>+</button> {/* Botón de añadir */}
            <button className="arrow-button" onClick={handleRequirementsSubmit}>➔</button> {/* Botón de flecha */}
          </div>
        )}

        {/* Paso 3: Seleccionar equipo */}
        {step === 3 && (
          <div className="step-content">
            <h2>Select your team</h2>
            <input
              type="text"
              value={teamInput}
              onChange={(e) => setTeamInput(e.target.value)}
              className="input-field"
              placeholder="Search team members"
            />
            <div className="team-results">
              {/* Miembros del equipo que podrían ser seleccionados */}
              {["Alice", "Bob", "Charlie"].map((member, index) => (
                <div key={index} className="team-member">
                  {member}
                  <button className="add-button" onClick={() => handleAddTeamMember(member)}>+</button>
                </div>
              ))}
            </div>
            <button className="arrow-button" onClick={handleFinalStep}>➔</button> {/* Botón de flecha */}
          </div>
        )}

        {/* Paso 4: Confirmar creación del proyecto */}
        {step === 4 && (
          <div className="step-content">
            <h2>Are you sure you want to create a new project?</h2>
            <div className="confirm-buttons">
              <button className="yes-button">Yes</button>
              <button className="no-button">No</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default NuevoProyecto;
